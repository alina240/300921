package com.company;

public class Main {

    public static void main(String[] args) {
        final double v = 343.0;
        final double t = 6.8;
        double s;
        s = t * v;
        System.out.println("Расстояние до места удара молнии: " + s + " метров");
    }
}