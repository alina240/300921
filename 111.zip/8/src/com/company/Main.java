package com.company;

public class Main {
    static int n=0;
    static  int array[][]={{8,5,9,2,7},{4,6,9,4,9},{-4,4,-6,7,5},{4,4,-7,2,6}};
    private static void meth(int k){
        for(int i=0;i<array.length;i++){

            if(k>array[i].length && k<=0)
                throw new IllegalArgumentException();}
        n=k-1;

        for(int i=0;i<array.length;i++){
            for(int j=0;j<array[i].length;j++){
                if(j==n)array[i][j]=0;
            }
        }
        for(int i=0;i<array.length;i++){
            for(int j=0;j<array[i].length;j++)
                System.out.print(array[i][j]+" ");
            System.out.println();
        }
    }
    public static void main(String[] args) {

        meth(1);
    }
}
